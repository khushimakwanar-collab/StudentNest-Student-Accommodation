<?php
// Database + session bootstrap. Override with env vars DB_HOST, DB_NAME, DB_USER, DB_PASS.
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
function db(): PDO {
    static $pdo = null;
    if (!$pdo) {
        $h = getenv('DB_HOST') ?: '127.0.0.1'; $n = getenv('DB_NAME') ?: 'student_nest';
        $u = getenv('DB_USER') ?: 'root'; $p = getenv('DB_PASS') ?: '';
        $pdo = new PDO("mysql:host=$h;dbname=$n;charset=utf8mb4", $u, $p, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false]);
    }
    return $pdo;
}
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function current_user_id(): ?int { return $_SESSION['user_id'] ?? null; }
function require_login(): void { if (!current_user_id()) { header('Location: login.php'); exit; } }
function guest_only(): void { if (current_user_id()) { header('Location: index.php'); exit; } }
function json_out(array $d, int $code = 200): void {
    http_response_code($code); header('Content-Type: application/json'); echo json_encode($d); exit;
}
