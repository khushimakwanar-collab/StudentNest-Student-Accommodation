<?php
require_once 'config/database.php';
$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare("SELECT * FROM properties WHERE id=?"); $st->execute([$id]); $p = $st->fetch();
if (!$p) { http_response_code(404); $title = 'Not found'; require 'includes/header.php'; echo '<div class="container py-5"><h2>Property not found</h2><a href="index.php">Back to listings</a></div>'; require 'includes/footer.php'; exit; }
$am = db()->prepare("SELECT a.name,a.icon FROM amenities a JOIN property_amenities pa ON pa.amenity_id=a.id WHERE pa.property_id=? ORDER BY a.name"); $am->execute([$id]); $amenities = $am->fetchAll();
$int = false; if (current_user_id()) { $q = db()->prepare("SELECT 1 FROM interested_users WHERE user_id=? AND property_id=?"); $q->execute([current_user_id(), $id]); $int = (bool)$q->fetch(); }
$gallery = array_filter(explode(',', $p['gallery']));
$title = $p['name']; require 'includes/header.php'; ?>
<main class="container py-4">
<div class="d-flex justify-content-between align-items-center mb-3"><a href="index.php#listing" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Back to listings</a><a href="index.php" class="btn-close" aria-label="Close" title="Close"></a></div>
<div class="row g-4"><div class="col-lg-7">
<div id="gal" class="carousel slide rounded-4 overflow-hidden shadow-sm" data-bs-ride="false"><div class="carousel-inner">
<?php foreach ($gallery as $i => $g): ?><div class="carousel-item <?= $i ? '' : 'active' ?>"><img src="assets/images/<?= e($g) ?>" class="d-block w-100" alt="<?= e($p['name']) ?> photo <?= $i + 1 ?>"></div><?php endforeach; ?></div>
<button class="carousel-control-prev" data-bs-target="#gal" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
<button class="carousel-control-next" data-bs-target="#gal" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button></div>
<div class="d-flex gap-2 mt-2"><?php foreach ($gallery as $i => $g): ?><img src="assets/images/<?= e($g) ?>" class="thumb" data-bs-target="#gal" data-bs-slide-to="<?= $i ?>" alt="thumbnail <?= $i + 1 ?>"><?php endforeach; ?></div></div>
<div class="col-lg-5"><h1 class="h2 fw-bold"><?= e($p['name']) ?></h1>
<p class="text-muted"><i class="bi bi-geo-alt-fill text-primary"></i> <?= e($p['address']) ?>, <?= e($p['city']) ?></p>
<div class="mb-3"><span class="badge rating-badge"><i class="bi bi-star-fill"></i> <?= number_format($p['rating'], 1) ?></span> <small class="text-muted">(<?= (int)$p['review_count'] ?> demo reviews)</small>
<span class="badge bg-info-subtle text-info-emphasis text-capitalize ms-2"><?= e($p['gender']) ?></span></div>
<div class="price-box mb-3"><span class="fs-2 fw-bold">₹<?= number_format($p['price']) ?></span> <span class="text-muted">/ month</span></div>
<button id="interestBtn" class="btn btn-lg w-100 <?= $int ? 'btn-danger' : 'btn-outline-danger' ?>" data-id="<?= $id ?>" data-on="<?= $int ? 1 : 0 ?>" data-logged="<?= current_user_id() ? 1 : 0 ?>">
<span class="spinner-border spinner-border-sm d-none"></span> <span class="lbl"><i class="bi bi-heart<?= $int ? '-fill' : '' ?>"></i> <?= $int ? 'Interested' : "I'm Interested" ?></span></button>
<p class="small text-muted mt-2">Demo contact: <?= e($p['owner_name']) ?> (fictional) &middot; <?= e($p['contact_phone']) ?></p></div></div>
<div class="row g-4 mt-1"><div class="col-lg-7"><h2 class="h4">About this property</h2><p><?= nl2br(e($p['description'])) ?></p></div>
<div class="col-lg-5"><h2 class="h4">Amenities</h2><div class="row g-2"><?php foreach ($amenities as $a): ?><div class="col-6"><div class="amenity"><i class="bi bi-<?= e($a['icon']) ?>"></i> <?= e($a['name']) ?></div></div><?php endforeach; ?></div></div></div>
</main>
<?php $scripts = ['assets/js/details.js']; require 'includes/footer.php'; ?>
