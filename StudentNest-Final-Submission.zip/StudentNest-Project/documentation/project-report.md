# Project Report: StudentNest – Student Accommodation Website
## 1. Introduction
StudentNest is a fictional student accommodation (PG) platform built as an academic project. All data is demo data.
## 2. Problem Statement
Students moving to a new city struggle to find suitable, affordable accommodation and to compare options quickly.
## 3. Objectives
Provide a searchable, filterable listing; show detailed property pages; let users register and shortlist properties; demonstrate PHP, MySQL, AJAX and React together.
## 4. Technologies Used
HTML5, CSS3, Bootstrap 5, JavaScript (fetch/AJAX), PHP 8 with PDO, MySQL/MariaDB, React 18 (esbuild bundle).
## 5. Main Features
- **Public browsing:** listing, details and filters are open to visitors; login is needed only to shortlist.
- **Property listing:** cards with image, name, area/city, price, gender, rating, amenities; data loaded from MySQL.
- **Property details:** Bootstrap carousel gallery with thumbnails, description, amenities, rating, interest button.
- **Filters:** city, maximum budget, gender – combinable, with loading and no-results states.
- **Shortlist:** logged-in users mark properties Interested/Uninterested; a shortlist page lists them.
## 6. Database Design
Tables: `users`, `properties`, `amenities`, `property_amenities` (many-to-many link, composite PK, FKs with cascade), `interested_users` (composite PK user_id+property_id, FKs to users and properties). Indexes on city, price, gender; unique index on user email. `database.sql` contains 12 fictional properties, 12 amenities and one demo user.
## 7. PHP Backend
`config/database.php` provides a PDO connection (exceptions, real prepared statements) and helpers. `api/properties.php` builds a parameterised query from filters and returns JSON. `api/interest.php` validates login and property, then inserts/deletes in `interested_users`.
## 8. Authentication
Signup validates input, rejects duplicate emails, stores `password_hash()` output; login uses `password_verify()` and `session_regenerate_id()`; logout destroys the session. Shortlisting requires a session (HTTP 401 JSON otherwise).
## 9. AJAX Functionality
`fetch()` requests update the listing on every filter change (spinner, error alert, empty state) and toggle Interested state with toast messages, without page reloads.
## 10. React Integration
`PropertyApp` (state: filters, data, loading, error; `useEffect` for fetching) renders `PropertyCard` components via props. Built to `assets/js/react-app.js` and loaded by `index.php`.
## 11. Testing
Tested against a live PHP 8.3 + MariaDB 10.11 stack: listing API, each and combined filters, empty result, details page and 404, signup, duplicate email, wrong password, login/logout and session redirect, add/remove interest with DB verification, anonymous 401, demo login, and PHP error log (clean). Also tested in headless Chromium: real filter, login and AJAX interest flows, plus overflow checks at mobile, tablet and desktop widths.
## 12. Deployment Approach
Any PHP + MySQL host: upload files, import `database.sql`, set DB credentials.
## 13. Screenshots
See the `screenshots/` folder: property-listing.png, property-details.png, ajax-interest.png (and mobile views).
## 14. Future Scope
Owner dashboard to add properties, reviews and ratings by students, map view, booking requests, email verification, admin panel and image uploads.
## 15. Conclusion
The project delivers a working, original full-stack accommodation portal combining PHP/MySQL with AJAX and React.
## Fictional data & image note
All names, addresses, phone numbers, reviews and ratings are invented. Images are original SVG illustrations created for this project.
