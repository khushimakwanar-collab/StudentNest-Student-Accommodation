<?php
require_once 'config/database.php';
$F = [
 'filters' => ['icon'=>'funnel','title'=>'Smart filters','tag'=>'Find the right stay in seconds',
  'intro'=>'Instead of scrolling through every listing, narrow the results to what matches your city, budget and preference. The list refreshes instantly, without reloading the page.',
  'benefits'=>[['geo-alt','City-wise search','Pick from Ahmedabad, Surat, Vadodara or Rajkot.'],['wallet2','Budget control','Set a maximum monthly rent and see only stays you can afford.'],['gender-ambiguous','Gender preference','Choose boys, girls or unisex accommodation.'],['lightning-charge','Instant results','Results update through AJAX with a loading indicator and a clear no-results message.']],
  'steps'=>['Choose a city from the City drop-down.','Select your maximum monthly budget.','Pick a gender preference, or combine all three filters.'],
  'cta'=>['Try the filters','index.php#listing']],
 'gallery' => ['icon'=>'images','title'=>'Photo galleries','tag'=>'See the space before you visit',
  'intro'=>'Every property has a photo gallery showing the room, the study area and the common lounge, so you know what to expect before you shortlist it.',
  'benefits'=>[['image','Room, study and lounge','Three views of each property in one gallery.'],['collection','Thumbnail navigation','Tap any thumbnail to jump straight to that photo.'],['arrows-fullscreen','Large carousel','Swipe or use the arrows on desktop and mobile.'],['phone','Mobile friendly','Images resize to fit every screen.']],
  'steps'=>['Open any property with View Details.','Use the arrows or thumbnails to browse photos.','Tap the heart if you like what you see.'],
  'cta'=>['See a sample gallery','property-details.php?id=__TOP__']],
 'shortlist' => ['icon'=>'heart','title'=>'Shortlist','tag'=>'Save favourites and decide later',
  'intro'=>'Mark the properties you like as Interested and they are saved to your account. Come back any time to review, compare and remove them.',
  'benefits'=>[['heart-fill','One-tap save','Use the heart on a card or the Interested button on a details page.'],['person-check','Saved to your account','Your shortlist is stored in the database against your login.'],['trash','Easy removal','Remove a property from the shortlist whenever you change your mind.'],['bar-chart','Interest count','See how many students showed interest in a property.']],
  'steps'=>['Log in to your account.','Click the heart on any property.','Open Shortlist from the menu to review your picks.'],
  'cta'=>['Open my shortlist','shortlist.php']],
 'amenities' => ['icon'=>'shield-check','title'=>'Amenity details','tag'=>'Know what is included',
  'intro'=>'Each property lists its amenities clearly, from Wi-Fi and meals to security and power backup, so you can compare what really matters to you.',
  'benefits'=>[['wifi','Everyday essentials','Wi-Fi, hot water, laundry and housekeeping details.'],['cup-hot','Food and comfort','Know whether meals, AC rooms or a lounge are included.'],['camera-video','Safety','CCTV security and power backup are marked on each property.'],['card-checklist','At-a-glance chips','Top amenities appear right on the property card.']],
  'steps'=>['Look at the amenity chips on each card.','Open View Details for the full amenity list.','Compare properties and shortlist the best fit.'],
  'cta'=>['Browse properties','index.php#listing']],
];
$key = $_GET['f'] ?? 'filters'; if (!isset($F[$key])) $key = 'filters'; $f = $F[$key];
$top = db()->query("SELECT id,name,city,cover_image,gallery,rating FROM properties ORDER BY rating DESC, id LIMIT 1")->fetch();
$f['cta'][1] = str_replace('__TOP__', $top['id'], $f['cta'][1]);
$total = (int)db()->query("SELECT COUNT(*) FROM properties")->fetchColumn();
$title = $f['title']; require 'includes/header.php'; ?>
<main class="container py-4">
<div class="d-flex justify-content-between align-items-center mb-3"><a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Back to home</a><a href="index.php" class="btn-close" aria-label="Close" title="Close"></a></div>
<ul class="nav nav-pills feat-tabs mb-4 flex-nowrap overflow-auto">
<?php foreach ($F as $k => $x): ?><li class="nav-item"><a class="nav-link text-nowrap <?= $k === $key ? 'active' : '' ?>" href="features.php?f=<?= $k ?>"><i class="bi bi-<?= $x['icon'] ?>"></i> <?= e($x['title']) ?></a></li><?php endforeach; ?></ul>
<div class="row g-4"><div class="col-lg-7">
<span class="badge bg-primary-subtle text-primary-emphasis mb-2">Why StudentNest</span>
<h1 class="fw-bold h2"><i class="bi bi-<?= $f['icon'] ?> text-primary"></i> <?= e($f['title']) ?></h1>
<p class="lead text-muted"><?= e($f['tag']) ?></p><p><?= e($f['intro']) ?></p>
<div class="row g-3 mt-1"><?php foreach ($f['benefits'] as $b): ?><div class="col-sm-6"><div class="benefit"><i class="bi bi-<?= $b[0] ?>"></i><div><h2 class="h6 mb-1"><?= e($b[1]) ?></h2><p class="small text-muted mb-0"><?= e($b[2]) ?></p></div></div></div><?php endforeach; ?></div></div>
<div class="col-lg-5"><div class="price-box"><h2 class="h5 mb-3">How it works</h2>
<?php foreach ($f['steps'] as $i => $s): ?><div class="d-flex gap-3 mb-3"><span class="step-no"><?= $i + 1 ?></span><span><?= e($s) ?></span></div><?php endforeach; ?>
<a class="btn btn-primary w-100 mt-2" href="<?= e($f['cta'][1]) ?>"><?= e($f['cta'][0]) ?> <i class="bi bi-arrow-right"></i></a></div></div></div>
<hr class="my-4">
<?php if ($key === 'filters'): $c = db()->query("SELECT city, COUNT(*) n, MIN(price) lo, MAX(price) hi FROM properties GROUP BY city ORDER BY city")->fetchAll(); ?>
<h2 class="h5 mb-3">Cities available (<?= $total ?> properties)</h2><div class="row g-3">
<?php foreach ($c as $r): ?><div class="col-6 col-lg-3"><div class="feat text-start"><h3><?= e($r['city']) ?></h3><p><?= (int)$r['n'] ?> properties<br>₹<?= number_format($r['lo']) ?> – ₹<?= number_format($r['hi']) ?> / month</p></div></div><?php endforeach; ?></div>
<?php elseif ($key === 'gallery'): ?>
<h2 class="h5 mb-3">Sample gallery: <?= e($top['name']) ?>, <?= e($top['city']) ?></h2><div class="row g-3">
<?php foreach (array_filter(explode(',', $top['gallery'])) as $g): ?><div class="col-md-4"><a href="property-details.php?id=<?= $top['id'] ?>"><img src="assets/images/<?= e($g) ?>" class="img-fluid rounded-4 shadow-sm" alt="<?= e($top['name']) ?> photo"></a></div><?php endforeach; ?></div>
<?php elseif ($key === 'shortlist'): $cnt = 0; if (current_user_id()) { $n = db()->prepare("SELECT COUNT(*) FROM interested_users WHERE user_id=?"); $n->execute([current_user_id()]); $cnt = (int)$n->fetchColumn(); } ?>
<div class="alert alert-info d-flex justify-content-between align-items-center flex-wrap gap-2"><span><?= current_user_id() ? 'You currently have <strong>' . $cnt . '</strong> shortlisted properties.' : 'Log in to save properties to your shortlist.' ?></span><a class="btn btn-sm btn-primary" href="<?= current_user_id() ? 'shortlist.php' : 'login.php' ?>"><?= current_user_id() ? 'View shortlist' : 'Login' ?></a></div>
<?php else: $a = db()->query("SELECT a.name,a.icon,COUNT(pa.property_id) n FROM amenities a LEFT JOIN property_amenities pa ON pa.amenity_id=a.id GROUP BY a.id ORDER BY a.name")->fetchAll(); ?>
<h2 class="h5 mb-3">Amenities across <?= $total ?> properties</h2><div class="row g-2">
<?php foreach ($a as $r): ?><div class="col-6 col-md-4 col-lg-3"><div class="amenity"><i class="bi bi-<?= e($r['icon']) ?>"></i> <?= e($r['name']) ?> <span class="text-muted small">(<?= (int)$r['n'] ?>)</span></div></div><?php endforeach; ?></div>
<?php endif; ?>
</main>
<?php require 'includes/footer.php'; ?>
