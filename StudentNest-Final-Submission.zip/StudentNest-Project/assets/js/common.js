// Shared helpers: toast messages + AJAX POST for interest toggling
function showToast(msg, type) {
  const el = document.createElement('div');
  el.className = 'toast align-items-center text-bg-' + (type || 'success') + ' border-0';
  el.innerHTML = '<div class="d-flex"><div class="toast-body"></div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>';
  el.querySelector('.toast-body').textContent = msg;
  document.getElementById('toast-area').appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 3000 }); t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
}
async function postInterest(propertyId, action) {
  const body = new URLSearchParams({ property_id: propertyId, action });
  const res = await fetch((window.APP && APP.interestApi) || 'api/interest.php', { method: 'POST', body, credentials: 'same-origin' });
  return res.json();
}
