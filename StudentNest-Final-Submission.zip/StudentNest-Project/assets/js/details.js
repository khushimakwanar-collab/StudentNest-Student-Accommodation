(function () {
  const btn = document.getElementById('interestBtn'); if (!btn) return;
  btn.addEventListener('click', async () => {
    if (btn.dataset.logged !== '1') { showToast('Please log in to shortlist properties.', 'warning'); setTimeout(() => location.href = 'login.php', 1200); return; }
    const on = btn.dataset.on === '1', sp = btn.querySelector('.spinner-border');
    btn.disabled = true; sp.classList.remove('d-none');
    try {
      const d = await postInterest(btn.dataset.id, on ? 'remove' : 'add');
      if (!d.success) throw new Error(d.message);
      btn.dataset.on = d.interested ? '1' : '0';
      btn.classList.toggle('btn-danger', d.interested); btn.classList.toggle('btn-outline-danger', !d.interested);
      btn.querySelector('.lbl').innerHTML = d.interested ? '<i class="bi bi-heart-fill"></i> Interested' : '<i class="bi bi-heart"></i> I\'m Interested';
      showToast(d.message);
    } catch (e) { showToast(e.message || 'Something went wrong.', 'danger'); }
    btn.disabled = false; sp.classList.add('d-none');
  });
})();
