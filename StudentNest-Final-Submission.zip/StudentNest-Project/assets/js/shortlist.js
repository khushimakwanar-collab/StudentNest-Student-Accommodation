document.querySelectorAll('.remove-btn').forEach(b => b.addEventListener('click', async () => {
  b.disabled = true;
  try {
    const d = await postInterest(b.dataset.id, 'remove'); if (!d.success) throw new Error(d.message);
    document.getElementById('card-' + b.dataset.id).remove(); showToast(d.message);
    if (!document.querySelector('[id^=card-]')) document.getElementById('empty').classList.remove('d-none');
  } catch (e) { showToast(e.message || 'Error', 'danger'); b.disabled = false; }
}));
