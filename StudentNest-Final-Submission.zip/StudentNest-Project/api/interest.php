<?php
// POST property_id, action=add|remove -> JSON. Login required.
require_once __DIR__ . '/../config/database.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['success' => false, 'message' => 'POST required.'], 405);
$uid = current_user_id();
if (!$uid) json_out(['success' => false, 'login_required' => true, 'message' => 'Please log in to shortlist properties.'], 401);
$pid = (int)($_POST['property_id'] ?? 0); $action = $_POST['action'] ?? '';
try {
    $chk = db()->prepare("SELECT id FROM properties WHERE id=?"); $chk->execute([$pid]);
    if (!$chk->fetch()) json_out(['success' => false, 'message' => 'Property not found.'], 404);
    if ($action === 'add') { db()->prepare("INSERT IGNORE INTO interested_users (user_id,property_id) VALUES (?,?)")->execute([$uid, $pid]); $msg = 'Added to your shortlist.'; }
    elseif ($action === 'remove') { db()->prepare("DELETE FROM interested_users WHERE user_id=? AND property_id=?")->execute([$uid, $pid]); $msg = 'Removed from your shortlist.'; }
    else json_out(['success' => false, 'message' => 'Invalid action.'], 400);
    $n = db()->prepare("SELECT COUNT(*) FROM interested_users WHERE property_id=?"); $n->execute([$pid]);
    json_out(['success' => true, 'message' => $msg, 'interested' => $action === 'add', 'interest_count' => (int)$n->fetchColumn()]);
} catch (Throwable $ex) { json_out(['success' => false, 'message' => 'Server error.'], 500); }
