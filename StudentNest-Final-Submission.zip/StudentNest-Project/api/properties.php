<?php
// GET /api/properties.php?city=&budget=&gender=  -> JSON list (AJAX filtering)
require_once __DIR__ . '/../config/database.php';
$city = trim($_GET['city'] ?? ''); $budget = (int)($_GET['budget'] ?? 0); $gender = trim($_GET['gender'] ?? '');
$sql = "SELECT p.id,p.name,p.city,p.area,p.price,p.gender,p.rating,p.review_count,p.cover_image,
  (SELECT GROUP_CONCAT(a.name ORDER BY a.name SEPARATOR ',') FROM property_amenities pa JOIN amenities a ON a.id=pa.amenity_id WHERE pa.property_id=p.id) AS amenities,
  (SELECT COUNT(*) FROM interested_users i WHERE i.property_id=p.id AND i.user_id=:uid) AS interested,
  (SELECT COUNT(*) FROM interested_users i WHERE i.property_id=p.id) AS interest_count
  FROM properties p WHERE 1=1";
$args = [':uid' => current_user_id() ?? 0];
if ($city !== '') { $sql .= " AND p.city=:city"; $args[':city'] = $city; }
if ($budget > 0) { $sql .= " AND p.price<=:budget"; $args[':budget'] = $budget; }
if (in_array($gender, ['male','female','unisex'], true)) { $sql .= " AND p.gender=:gender"; $args[':gender'] = $gender; }
$sql .= " ORDER BY p.rating DESC, p.price ASC";
try {
    $st = db()->prepare($sql); $st->execute($args); $rows = $st->fetchAll();
    foreach ($rows as &$r) { $r['amenities'] = $r['amenities'] ? explode(',', $r['amenities']) : []; $r['interested'] = (bool)$r['interested']; }
    $c = db()->query("SELECT DISTINCT city FROM properties ORDER BY city")->fetchAll(PDO::FETCH_COLUMN);
    json_out(['success' => true, 'count' => count($rows), 'cities' => $c, 'logged_in' => (bool)current_user_id(), 'properties' => $rows]);
} catch (Throwable $ex) { json_out(['success' => false, 'message' => 'Could not load properties.'], 500); }
