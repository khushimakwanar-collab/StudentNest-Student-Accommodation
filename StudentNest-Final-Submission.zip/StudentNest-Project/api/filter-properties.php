<?php
// Alias of properties.php (AJAX filtering endpoint).
require __DIR__ . '/properties.php';
