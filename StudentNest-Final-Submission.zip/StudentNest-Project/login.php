<?php
require_once 'config/database.php'; guest_only(); $err = ''; $email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $st = db()->prepare("SELECT * FROM users WHERE email=?"); $st->execute([$email]); $u = $st->fetch();
    if ($u && password_verify($_POST['password'] ?? '', $u['password_hash'])) {
        session_regenerate_id(true); $_SESSION['user_id'] = (int)$u['id']; $_SESSION['user_name'] = $u['name']; header('Location: index.php'); exit;
    }
    $err = 'Incorrect email or password.';
}
$title = 'Login'; require 'includes/header.php'; ?>
<main class="container py-5"><div class="row justify-content-center"><div class="col-md-6 col-lg-5"><div class="card auth-card shadow-sm p-4">
<h1 class="h3 fw-bold mb-3">Welcome back</h1>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
<form method="post">
<div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= e($email) ?>" required></div>
<div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
<button class="btn btn-primary w-100">Login</button></form>
<p class="mt-3 mb-1 text-center small">New here? <a href="signup.php">Create an account</a></p>
<p class="text-center small text-muted mb-0">Demo: demo.student@example.com / Demo@123</p></div></div></div></main>
<?php require 'includes/footer.php'; ?>
