import React, { useState, useEffect, useCallback } from 'react';
import PropertyCard from './PropertyCard.jsx';

const BUDGETS = [5000, 7000, 9000, 12000];

export default function PropertyApp() {
  const [filters, setFilters] = useState({ city: '', budget: '', gender: '' });
  const [data, setData] = useState({ properties: [], cities: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  // AJAX: re-fetch from the PHP/MySQL API whenever a filter changes
  useEffect(() => {
    const ctrl = new AbortController();
    const qs = new URLSearchParams(filters).toString();
    setLoading(true); setError('');
    fetch(window.APP.api + '?' + qs, { signal: ctrl.signal, credentials: 'same-origin' })
      .then(r => r.json())
      .then(d => { if (!d.success) throw new Error(d.message); setData(d); setLoading(false); })
      .catch(e => { if (e.name !== 'AbortError') { setError(e.message || 'Failed to load properties.'); setLoading(false); } });
    return () => ctrl.abort();
  }, [filters]);

  const set = k => e => setFilters(f => ({ ...f, [k]: e.target.value }));

  const toggle = useCallback(async p => {
    if (!window.APP.loggedIn) { showToast('Please log in to shortlist properties.', 'warning'); setTimeout(() => location.href = 'login.php', 1200); return; }
    setBusyId(p.id);
    try {
      const d = await postInterest(p.id, p.interested ? 'remove' : 'add');
      if (!d.success) throw new Error(d.message);
      setData(s => ({ ...s, properties: s.properties.map(x => x.id === p.id ? { ...x, interested: d.interested } : x) }));
      showToast(d.message);
    } catch (e) { showToast(e.message || 'Something went wrong.', 'danger'); }
    setBusyId(null);
  }, []);

  return (
    <>
      <div className="card filter-bar shadow p-3 mb-4 border-0">
        <div className="row g-2 align-items-end">
          <div className="col-md-3 col-6"><label className="form-label small mb-1">City</label>
            <select className="form-select" value={filters.city} onChange={set('city')} aria-label="City">
              <option value="">All cities</option>{data.cities.map(c => <option key={c}>{c}</option>)}</select></div>
          <div className="col-md-3 col-6"><label className="form-label small mb-1">Max budget</label>
            <select className="form-select" value={filters.budget} onChange={set('budget')} aria-label="Budget">
              <option value="">Any budget</option>{BUDGETS.map(b => <option key={b} value={b}>Up to ₹{b.toLocaleString('en-IN')}</option>)}</select></div>
          <div className="col-md-3 col-6"><label className="form-label small mb-1">Gender</label>
            <select className="form-select" value={filters.gender} onChange={set('gender')} aria-label="Gender">
              <option value="">Any</option><option value="male">Boys</option><option value="female">Girls</option><option value="unisex">Unisex</option></select></div>
          <div className="col-md-3 col-6"><button className="btn btn-outline-primary w-100" onClick={() => setFilters({ city: '', budget: '', gender: '' })}>Reset filters</button></div>
        </div>
      </div>
      <div className="d-flex justify-content-between mb-2">
        <h2 className="h5 mb-0">{loading ? 'Searching…' : data.properties.length + ' properties found'}</h2>
        {loading && <div className="spinner-border spinner-border-sm text-primary" role="status" />}
      </div>
      {error && <div className="alert alert-danger">{error}</div>}
      {!loading && !error && data.properties.length === 0 &&
        <div className="text-center py-5 text-muted"><i className="bi bi-search fs-1" /><p className="mt-2">No properties match your filters. Try widening your budget or city.</p></div>}
      <div className="row g-4" style={{ opacity: loading ? 0.5 : 1 }}>
        {data.properties.map(p => <PropertyCard key={p.id} p={p} busy={busyId === p.id} onToggle={toggle} />)}
      </div>
    </>
  );
}
