import React from 'react';
// Presentational component: receives a property + handlers via props
export default function PropertyCard({ p, busy, onToggle }) {
  return (
    <div className="col-md-6 col-lg-4">
      <div className="card prop-card h-100 position-relative">
        <img src={'assets/images/' + p.cover_image} className="card-img-top" alt={p.name} loading="lazy" />
        <button className="heart-btn" disabled={busy} onClick={() => onToggle(p)} aria-label="Toggle interested"
          title={p.interested ? 'Remove from shortlist' : 'Add to shortlist'}>
          {busy ? <span className="spinner-border spinner-border-sm" /> : <i className={'bi bi-heart' + (p.interested ? '-fill' : '')} />}
        </button>
        <div className="card-body d-flex flex-column">
          <div className="d-flex justify-content-between align-items-start">
            <h2 className="h5 mb-1">{p.name}</h2>
            <span className="badge rating-badge"><i className="bi bi-star-fill" /> {Number(p.rating).toFixed(1)}</span>
          </div>
          <p className="text-muted small mb-2"><i className="bi bi-geo-alt-fill text-primary" /> {p.area}, {p.city}</p>
          <div className="mb-2">{p.amenities.slice(0, 4).map(a => <span className="chip" key={a}>{a}</span>)}</div>
          <div className="d-flex justify-content-between align-items-center mt-auto">
            <div><span className="fs-5 fw-bold">₹{Number(p.price).toLocaleString('en-IN')}</span><small className="text-muted">/mo</small>
              <span className="badge bg-light text-dark border ms-2 text-capitalize">{p.gender}</span></div>
            <a className="btn btn-primary btn-sm" href={'property-details.php?id=' + p.id}>View Details</a>
          </div>
        </div>
      </div>
    </div>
  );
}
