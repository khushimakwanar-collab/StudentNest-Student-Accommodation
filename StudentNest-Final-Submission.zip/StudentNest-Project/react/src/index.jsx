import React from 'react';
import { createRoot } from 'react-dom/client';
import PropertyApp from './PropertyApp.jsx';
createRoot(document.getElementById('react-root')).render(<PropertyApp />);
