# StudentNest – Student Accommodation Website
Academic full-stack project (Internshala: Full Stack Web Development with AI). Browse, filter and shortlist student PGs.
**All properties, names, addresses, images, reviews and accounts are fictional demo data.**

## Features
- Public browsing: property listing, details page and filters work without login
- Property cards: image, name, area/city, price, gender, rating, amenities
- AJAX filters (city, budget, gender – combinable) with loading, error and no-results states
- Details page: image gallery (carousel + thumbnails), amenities, description, rating
- Signup / Login / Logout using PHP sessions, `password_hash()` / `password_verify()`
- Interested / Shortlist with AJAX (login required); shortlist page
- "Why StudentNest" feature pages, responsive Bootstrap 5 UI, React-powered listing

## Technologies
HTML5, CSS3, Bootstrap 5 (bundled locally in `assets/vendor`), JavaScript (fetch), PHP 8 (PDO), MySQL/MariaDB, React 18 (esbuild).

## Folder structure
```
index.php  property-details.php  features.php  login.php  signup.php  logout.php  shortlist.php
config/database.php     DB connection, session setup, helpers
includes/               header (navbar), footer
api/                    properties.php, filter-properties.php, interest.php (JSON)
assets/css|js|images    styles, scripts, original SVG illustrations, React bundle
assets/vendor           Bootstrap + Bootstrap Icons (local copy, works offline)
react/                  React source (src/*.jsx) + package.json
database.sql            schema + fictional sample data
documentation/          project-report.md
screenshots/            real screenshots of the running project
README.md  SUBMISSION_INFO.md
```

## Database setup
Tables: `users`, `properties`, `amenities`, `property_amenities` (many-to-many), `interested_users` (user ↔ property, composite PK, foreign keys with ON DELETE CASCADE).
1. Start MySQL (XAMPP/WAMP or any MySQL server).
2. Import: `mysql -u root < database.sql` or phpMyAdmin → Import → `database.sql`. This creates database `student_nest` with 12 fictional properties.

## Run locally
1. Copy the folder to `htdocs` (XAMPP) **or** run `php -S localhost:8000` inside the folder.
2. If your MySQL login differs, edit `config/database.php` or set env vars `DB_HOST DB_NAME DB_USER DB_PASS` (defaults: 127.0.0.1, student_nest, root, empty password).
3. Open `http://localhost/<folder>/index.php` (or `http://localhost:8000`).

## Login / Signup
Demo account (fictional): `demo.student@example.com` / `Demo@123`. You can also create your own account. Guests can browse; Interested/Shortlist asks the visitor to log in.

## How AJAX works
Filter changes call `api/properties.php?city=&budget=&gender=` with `fetch()`; the JSON result re-renders the cards without reloading. The heart / "I'm Interested" buttons POST to `api/interest.php` (`property_id`, `action=add|remove`), show a loading spinner, and update the button and a toast from the JSON response. Not logged in → HTTP 401 JSON → the user is sent to the login page.

## React feature
`react/src/PropertyApp.jsx` (state, `useEffect`, fetch, filters) and `PropertyCard.jsx` (props) render the listing on `index.php`. The compiled `assets/js/react-app.js` is included. To rebuild: `cd react && npm install && npm run build`.

## Shortlist / Interested
Stored in `interested_users`. Add/remove works from cards and the details page; `shortlist.php` lists saved properties (login required).

## Testing
Tested on PHP 8.3 + MariaDB 10.11 with a headless Chromium browser: listing (12 cards), each and combined filters, no-result state, details + gallery, signup, duplicate email, wrong password, login/logout, guest 401 on interest, add/remove interest with DB check, XSS escaping of user input, and no horizontal overflow at 390, 768, 1024 and 1440 px widths.

## Screenshots
`screenshots/property-listing.png`, `property-details.png`, `ajax-interest.png` (+ `mobile-listing.png`, `mobile-details.png`).

## Deployment
Upload files to any PHP + MySQL host, create a database, import `database.sql`, set credentials in `config/database.php`.

GitHub Repository: [ADD GITHUB REPOSITORY URL]
Live Project: [ADD LIVE PROJECT URL]

*Academic project. All properties, names, addresses, images and data are fictional and created for educational/demo purposes.*
