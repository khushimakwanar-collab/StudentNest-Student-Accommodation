# Submission Information

**Project:** StudentNest – Student Accommodation Website
**Student:** Khushi Makwana
**College:** JG University
**Course:** CE
**Subject:** DSA

**GitHub Repository:** [ADD GITHUB REPOSITORY URL]
**Live Project URL:** [ADD LIVE PROJECT URL]

## Screenshots
- screenshots/property-listing.png
- screenshots/property-details.png
- screenshots/ajax-interest.png

Additional real screenshots: screenshots/mobile-listing.png, screenshots/mobile-details.png

## Demo login (fictional)
demo.student@example.com / Demo@123
