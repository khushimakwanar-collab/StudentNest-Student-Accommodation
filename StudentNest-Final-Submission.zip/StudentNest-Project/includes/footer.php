<footer class="site-footer mt-5"><div class="container">
<div class="row gy-4 footer-main">
<div class="col-lg-5 pe-lg-5"><a class="footer-brand" href="<?= $base ?? '' ?>index.php"><i class="bi bi-house-heart-fill"></i> Student<span>Nest</span></a>
<p class="footer-text mt-3 mb-0">Student accommodation search made simple. Compare stays by city, budget and gender, browse photos and amenities, and shortlist the places that suit you.</p></div>
<div class="col-6 col-lg-2"><div class="footer-head">Platform</div><ul class="footer-links">
<li><a href="<?= $base ?? '' ?>index.php#listing">Find a PG</a></li><li><a href="<?= $base ?? '' ?>shortlist.php">My Shortlist</a></li><li><a href="<?= $base ?? '' ?>features.php?f=filters">Why StudentNest</a></li>
<li><a href="<?= $base ?? '' ?>login.php">Login</a></li><li><a href="<?= $base ?? '' ?>signup.php">Create account</a></li></ul></div>
<div class="col-6 col-lg-2"><div class="footer-head">Cities</div><ul class="footer-links"><li>Ahmedabad</li><li>Surat</li><li>Vadodara</li><li>Rajkot</li></ul></div>
<div class="col-lg-3"><div class="footer-head">Contact</div><ul class="footer-links footer-text">
<li>support@studentnest.example</li><li>+91 90000 00000</li><li>Student Zone, Ahmedabad</li></ul></div></div>
<div class="footer-bottom"><span>&copy; <?= date('Y') ?> StudentNest</span>
<span>Academic project. All properties, names, addresses, images and data shown on this website are fictional and created for educational/demo purposes.</span></div>
</div></footer>
<script src="<?= $base ?? "" ?>assets/vendor/bootstrap/bootstrap.bundle.min.js"></script>
<script src="<?= $base ?? '' ?>assets/js/common.js"></script>
<?php foreach (($scripts ?? []) as $s): ?><script src="<?= e($s) ?>"></script><?php endforeach; ?>
</body></html>
