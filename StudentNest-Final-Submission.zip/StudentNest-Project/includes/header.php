<?php require_once __DIR__ . '/../config/database.php'; $base = $base ?? ''; ?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'StudentNest') ?> | StudentNest</title>
<link href="<?= $base ?>assets/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
<link href="<?= $base ?>assets/vendor/bootstrap-icons/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= $base ?>assets/css/style.css" rel="stylesheet"></head><body>
<nav class="navbar navbar-expand-lg sticky-top bg-white shadow-sm"><div class="container">
<a class="navbar-brand fw-bold brand" href="<?= $base ?>index.php"><i class="bi bi-house-heart-fill"></i> Student<span>Nest</span></a>
<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="nav"><ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
<li class="nav-item"><a class="nav-link" href="<?= $base ?>index.php#listing">Find a PG</a></li>
<?php if (current_user_id()): ?>
<li class="nav-item"><a class="nav-link" href="<?= $base ?>shortlist.php"><i class="bi bi-heart"></i> Shortlist</a></li>
<li class="nav-item"><span class="nav-link text-muted">Hi, <?= e($_SESSION['user_name']) ?></span></li>
<li class="nav-item"><a class="btn btn-outline-primary btn-sm" href="<?= $base ?>logout.php">Logout</a></li>
<?php else: ?>
<li class="nav-item"><a class="nav-link" href="<?= $base ?>login.php">Login</a></li>
<li class="nav-item"><a class="btn btn-primary btn-sm" href="<?= $base ?>signup.php">Sign up</a></li>
<?php endif; ?></ul></div></div></nav>
<div id="toast-area" class="toast-container position-fixed bottom-0 end-0 p-3"></div>
