<?php
require_once 'config/database.php';
if (!current_user_id()) { header('Location: login.php'); exit; }
$st = db()->prepare("SELECT p.* FROM properties p JOIN interested_users i ON i.property_id=p.id WHERE i.user_id=? ORDER BY i.created_at DESC"); $st->execute([current_user_id()]); $rows = $st->fetchAll();
$title = 'My shortlist'; require 'includes/header.php'; ?>
<main class="container py-4"><div class="d-flex justify-content-between align-items-center mb-3"><a href="index.php#listing" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Back to listings</a><a href="index.php" class="btn-close" aria-label="Close" title="Close"></a></div>
<h1 class="h3 fw-bold mb-3">My shortlist</h1>
<div id="empty" class="alert alert-info <?= $rows ? 'd-none' : '' ?>">No shortlisted properties yet. <a href="index.php">Browse listings</a></div>
<div class="row g-4"><?php foreach ($rows as $p): ?><div class="col-md-6 col-lg-4" id="card-<?= $p['id'] ?>"><div class="card prop-card h-100">
<img src="assets/images/<?= e($p['cover_image']) ?>" class="card-img-top" alt="<?= e($p['name']) ?>"><div class="card-body">
<h2 class="h5"><?= e($p['name']) ?></h2><p class="text-muted small mb-1"><i class="bi bi-geo-alt"></i> <?= e($p['area']) ?>, <?= e($p['city']) ?></p>
<p class="fw-bold mb-2">₹<?= number_format($p['price']) ?>/mo</p>
<a href="property-details.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm">View Details</a>
<button class="btn btn-outline-danger btn-sm remove-btn" data-id="<?= $p['id'] ?>">Remove</button></div></div></div><?php endforeach; ?></div></main>
<?php $scripts = ['assets/js/shortlist.js']; require 'includes/footer.php'; ?>
