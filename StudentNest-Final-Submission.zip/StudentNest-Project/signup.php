<?php
require_once 'config/database.php'; guest_only(); $err = []; $v = ['name'=>'','email'=>'','phone'=>''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v = ['name'=>trim($_POST['name']??''),'email'=>strtolower(trim($_POST['email']??'')),'phone'=>trim($_POST['phone']??'')]; $pw = $_POST['password'] ?? '';
    if (strlen($v['name']) < 2) $err[] = 'Please enter your name.';
    if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL)) $err[] = 'Enter a valid email address.';
    if (!preg_match('/^[0-9+\- ]{7,15}$/', $v['phone'])) $err[] = 'Enter a valid phone number.';
    if (strlen($pw) < 6) $err[] = 'Password must be at least 6 characters.';
    if (!$err) {
        $c = db()->prepare("SELECT id FROM users WHERE email=?"); $c->execute([$v['email']]);
        if ($c->fetch()) $err[] = 'An account with this email already exists.';
        else {
            db()->prepare("INSERT INTO users (name,email,password_hash,phone) VALUES (?,?,?,?)")->execute([$v['name'],$v['email'],password_hash($pw, PASSWORD_DEFAULT),$v['phone']]);
            session_regenerate_id(true); $_SESSION['user_id'] = (int)db()->lastInsertId(); $_SESSION['user_name'] = $v['name'];
            header('Location: index.php'); exit;
        }
    }
}
$title = 'Sign up'; require 'includes/header.php'; ?>
<main class="container py-5"><div class="row justify-content-center"><div class="col-md-6 col-lg-5"><a href="login.php" class="btn btn-outline-secondary btn-sm mb-3"><i class="bi bi-arrow-left"></i> Back to login</a><div class="card auth-card shadow-sm p-4">
<h1 class="h3 fw-bold mb-3">Create your account</h1>
<?php foreach ($err as $x): ?><div class="alert alert-danger py-2"><?= e($x) ?></div><?php endforeach; ?>
<form method="post" novalidate>
<div class="mb-3"><label class="form-label">Name</label><input name="name" class="form-control" value="<?= e($v['name']) ?>" required></div>
<div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= e($v['email']) ?>" required></div>
<div class="mb-3"><label class="form-label">Phone</label><input name="phone" class="form-control" value="<?= e($v['phone']) ?>" required></div>
<div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" minlength="6" required></div>
<button class="btn btn-primary w-100">Sign up</button></form>
<p class="mt-3 mb-0 text-center small">Already registered? <a href="login.php">Login</a></p></div></div></div></main>
<?php require 'includes/footer.php'; ?>
